<section class="hero-banner">
  <div class="hero-content">
    <h1>El primer paso a tu vida profesional</h1>
    <p>Instituto Nor Oriental de la Selva</p>
    <a href="inscripcion.php" class="btn btn-hero">
      Inscríbete ahora <i class="bi bi-arrow-right"></i>
    </a>
  </div>
</section>
